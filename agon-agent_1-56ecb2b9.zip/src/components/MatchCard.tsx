import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Radio, Clock } from 'lucide-react';
import type { Match } from '../lib/types';
import TeamLogo from './TeamLogo';
import ParticleCanvas from './ParticleCanvas';
import { getSportGradient, getSportName } from '../lib/sports';

function formatTime(ts: number) {
  const d = new Date(ts);
  return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

function formatDateLabel(ts: number) {
  const d = new Date(ts);
  const today = new Date();
  const tomorrow = new Date();
  tomorrow.setDate(today.getDate() + 1);

  if (d.toDateString() === today.toDateString()) return 'Today';
  if (d.toDateString() === tomorrow.toDateString()) return 'Tomorrow';
  return d.toLocaleDateString([], { weekday: 'short', month: 'short', day: 'numeric' });
}

export default function MatchCard({ match, index = 0 }: { match: Match; index?: number }) {
  const gradient = getSportGradient(match.sport);
  const sportName = getSportName(match.sport);
  const totalStreams =
    (match.watchfooty?.streams.length || 0) + (match.streamed?.sources.length || 0);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay: Math.min(index * 0.04, 0.4) }}
      whileHover={{ y: -6, scale: 1.01 }}
      className="group relative"
    >
      <Link to={`/match/${encodeURIComponent(match.uid)}`} className="block">
        <div className="relative overflow-hidden rounded-2xl border border-white/10 bg-slate-900/80 backdrop-blur-xl transition-all duration-300 group-hover:border-white/20 group-hover:shadow-2xl group-hover:shadow-cyan-500/10">
          {/* Animated gradient background */}
          <div className={`absolute inset-0 bg-gradient-to-br ${gradient} opacity-[0.12]`} />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-900/40 to-transparent" />

          {/* Particle background */}
          <div className="absolute inset-0 opacity-60 transition-opacity duration-500 group-hover:opacity-100">
            <ParticleCanvas
              colors={['#22d3ee', '#3b82f6', '#a855f7', '#ec4899']}
              count={25}
              intensity={0.6}
            />
          </div>

          {/* Status badge */}
          <div className="absolute left-3 top-3 z-10 flex items-center gap-2">
            {match.live ? (
              <div className="flex items-center gap-1.5 rounded-full bg-red-500/90 px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider text-white shadow-lg shadow-red-500/30">
                <Radio className="h-3 w-3 animate-pulse" />
                Live
              </div>
            ) : (
              <div className="flex items-center gap-1.5 rounded-full bg-slate-700/80 px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider text-slate-300 backdrop-blur-sm">
                <Clock className="h-3 w-3" />
                {formatDateLabel(match.date)}
              </div>
            )}
            {match.featuredScore >= 80 && (
              <div className="rounded-full bg-amber-500/90 px-2 py-1 text-[10px] font-bold uppercase tracking-wider text-white shadow-lg shadow-amber-500/20">
                Featured
              </div>
            )}
          </div>

          {/* Stream count badge */}
          <div className="absolute right-3 top-3 z-10">
            <div className="rounded-full bg-black/40 px-2 py-1 text-[10px] font-semibold text-cyan-300 backdrop-blur-sm">
              {totalStreams} {totalStreams === 1 ? 'source' : 'sources'}
            </div>
          </div>

          {/* Content */}
          <div className="relative z-10 flex flex-col items-center gap-3 px-4 pb-4 pt-14">
            {/* Teams with floating logos */}
            <div className="flex w-full items-center justify-between gap-2">
              {/* Home team */}
              <div className="flex flex-1 flex-col items-center gap-1.5">
                <motion.div
                  animate={{ y: [0, -6, 0] }}
                  transition={{ duration: 3, repeat: Infinity, ease: 'easeInOut' }}
                  className="drop-shadow-lg"
                >
                  <TeamLogo src={match.homeTeam.logo} name={match.homeTeam.name} className="h-14 w-14 sm:h-16 sm:w-16" />
                </motion.div>
                <span className="text-center text-xs font-semibold text-white line-clamp-2">
                  {match.homeTeam.name || 'TBD'}
                </span>
              </div>

              {/* VS / Score */}
              <div className="flex flex-col items-center px-2">
                {match.live ? (
                  <div className="flex items-center gap-2">
                    <span className="text-2xl font-black text-white tabular-nums">
                      {match.homeScore ?? 0}
                    </span>
                    <span className="text-sm font-bold text-slate-400">-</span>
                    <span className="text-2xl font-black text-white tabular-nums">
                      {match.awayScore ?? 0}
                    </span>
                  </div>
                ) : (
                  <div className="rounded-lg bg-white/5 px-3 py-1.5 text-xs font-bold uppercase tracking-widest text-slate-400">
                    VS
                  </div>
                )}
                {match.minute && match.live && (
                  <span className="mt-1 text-[10px] font-semibold text-red-400">
                    {match.minute}
                  </span>
                )}
              </div>

              {/* Away team */}
              <div className="flex flex-1 flex-col items-center gap-1.5">
                <motion.div
                  animate={{ y: [0, -6, 0] }}
                  transition={{ duration: 3, repeat: Infinity, ease: 'easeInOut', delay: 1.5 }}
                  className="drop-shadow-lg"
                >
                  <TeamLogo src={match.awayTeam.logo} name={match.awayTeam.name} className="h-14 w-14 sm:h-16 sm:w-16" />
                </motion.div>
                <span className="text-center text-xs font-semibold text-white line-clamp-2">
                  {match.awayTeam.name || 'TBD'}
                </span>
              </div>
            </div>

            {/* League + time */}
            <div className="flex w-full items-center justify-between border-t border-white/5 pt-3 text-[11px]">
              <span className="truncate font-medium text-slate-400">
                {match.league || sportName}
              </span>
              <span className="shrink-0 font-semibold text-slate-300">{formatTime(match.date)}</span>
            </div>
          </div>

          {/* Hover watch button */}
          <div className="absolute inset-x-0 bottom-0 z-20 translate-y-full bg-gradient-to-t from-cyan-500 to-blue-600 py-2.5 text-center text-xs font-bold uppercase tracking-wider text-white transition-transform duration-300 group-hover:translate-y-0">
            Watch Now →
          </div>
        </div>
      </Link>
    </motion.div>
  );
}
