import { useEffect, useRef, useState } from 'react';
import { AlertCircle, Shield, Loader2 } from 'lucide-react';

interface IframePlayerProps {
  src: string;
  title?: string;
  onDeadStream?: () => void;
  /** When true, applies a strict sandbox that blocks popup/redirect ads.
   *  Disable for sources already cleaned server-side (e.g. WatchFooty proxy),
   *  since their nested player detects the sandbox and refuses to load. */
  sandbox?: boolean;
}

export default function IframePlayer({ src, title = 'Stream', onDeadStream, sandbox = true }: IframePlayerProps) {
  const [loading, setLoading] = useState(true);
  const [dead, setDead] = useState(false);
  const deadCheckedRef = useRef(false);

  useEffect(() => {
    setLoading(true);
    setDead(false);
    deadCheckedRef.current = false;
  }, [src]);

  // Detect dead streams: For WatchFooty sources served through our proxy,
  // we check if the proxy marked the page as having no video. We do this
  // by fetching the proxy URL ourselves and checking for a marker comment
  // the proxy injects. This avoids cross-origin iframe inspection issues.
  useEffect(() => {
    if (!src.includes('/api/wf-embed') || deadCheckedRef.current) return;
    deadCheckedRef.current = true;

    const checkStream = async () => {
      try {
        const res = await fetch(src);
        const html = await res.text();
        // The proxy injects this marker when the upstream page has no video iframe
        if (html.includes('<!-- no-video-available -->')) {
          setDead(true);
          setLoading(false);
          // Notify parent to auto-advance after a short delay
          setTimeout(() => {
            onDeadStream?.();
          }, 1500);
        }
      } catch {
        // If check fails, let the iframe try to load normally
      }
    };

    // Give the iframe a moment to start loading first
    const timer = setTimeout(checkStream, 3000);
    return () => clearTimeout(timer);
  }, [src, onDeadStream]);

  if (!src) {
    return (
      <div className="flex aspect-video w-full flex-col items-center justify-center gap-3 rounded-xl bg-black">
        <AlertCircle className="h-10 w-10 text-slate-600" />
        <p className="text-sm text-slate-400">No stream selected</p>
      </div>
    );
  }

  if (dead) {
    return (
      <div className="flex aspect-video w-full flex-col items-center justify-center gap-3 rounded-xl bg-black">
        <AlertCircle className="h-10 w-10 text-red-400" />
        <p className="text-sm text-slate-300">This source has no active video.</p>
        <p className="text-xs text-slate-500">Switching to next source automatically...</p>
      </div>
    );
  }

  return (
    <div className="relative aspect-video w-full overflow-hidden rounded-xl bg-black">
      {/*
        SANDBOX STRATEGY — ad suppression without breaking the video:
        - allow-scripts: stream player JS must run
        - allow-same-origin: needed for the player to access its own storage/cookies
        - OMIT allow-popups: popup ads (window.open, target=_blank) are silently blocked
        - OMIT allow-top-navigation: redirect ads cannot navigate our page away
        - OMIT allow-popups-to-escape-sandbox: popups can't escape restrictions
        This lets the video play while neutralizing the aggressive popup/redirect ads
        that embed.st injects. The stream itself runs entirely within the iframe origin.
      */}
      {loading && (
        <div className="absolute inset-0 z-10 flex flex-col items-center justify-center gap-2 bg-black">
          <Loader2 className="h-8 w-8 animate-spin text-cyan-400" />
          <p className="text-xs text-slate-400">Loading stream...</p>
        </div>
      )}
      <iframe
        src={src}
        title={title}
        className="h-full w-full"
        frameBorder="0"
        allow="autoplay; fullscreen; encrypted-media; picture-in-picture"
        allowFullScreen
        {...(sandbox ? { sandbox: 'allow-scripts allow-same-origin allow-presentation' } : {})}
        referrerPolicy="no-referrer"
        onLoad={() => setLoading(false)}
      />
      <div className="pointer-events-none absolute right-2 top-2 flex items-center gap-1 rounded-md bg-black/60 px-2 py-1 text-[10px] font-medium text-emerald-400 backdrop-blur-sm">
        <Shield className="h-3 w-3" /> Ad-Protected
      </div>
    </div>
  );
}
