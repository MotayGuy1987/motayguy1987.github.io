import { useState } from 'react';

interface TeamLogoProps {
  src: string;
  name: string;
  className?: string;
}

export default function TeamLogo({ src, name, className = 'h-12 w-12' }: TeamLogoProps) {
  const [error, setError] = useState(false);
  const [loading, setLoading] = useState(true);

  const proxiedSrc = src ? `/api/img?url=${encodeURIComponent(src)}` : '';
  const initials = (name || '?').split(/\s+/).slice(0, 2).map(w => w[0]).join('').toUpperCase();

  if (!src || error) {
    return (
      <div className={`${className} flex items-center justify-center rounded-full bg-gradient-to-br from-slate-700 to-slate-800 text-xs font-bold text-slate-300 ring-1 ring-white/10`}>
        {initials || '?'}
      </div>
    );
  }

  return (
    <div className={`${className} relative flex items-center justify-center rounded-full ring-1 ring-white/10`}>
      {loading && (
        <div className="absolute inset-0 animate-pulse rounded-full bg-slate-700/50" />
      )}
      <img
        src={proxiedSrc}
        alt={name}
        loading="lazy"
        className={`h-full w-full rounded-full object-contain transition-opacity duration-300 ${loading ? 'opacity-0' : 'opacity-100'}`}
        onLoad={() => setLoading(false)}
        onError={() => setError(true)}
      />
    </div>
  );
}
