export interface Team {
  name: string;
  logo: string;
}

export interface WFStream {
  id: string;
  url: string;
  quality: string;
  language: string;
  ads: boolean;
  isRedirect: boolean;
  nsfw: boolean;
  provider: string;
}

export interface SPSource {
  source: string;
  id: string;
}

export interface Match {
  uid: string;
  title: string;
  sport: string;
  league: string;
  date: number;
  homeTeam: Team;
  awayTeam: Team;
  homeScore: number | null;
  awayScore: number | null;
  minute: string;
  poster: string;
  leagueLogo: string;
  popular: boolean;
  live: boolean;
  featuredScore: number;
  watchfooty: { matchId: string; streams: WFStream[] } | null;
  streamed: { matchId: string; sources: SPSource[] } | null;
}

export interface StreamedStream {
  id: string;
  streamNo: number;
  language: string;
  hd: boolean;
  embedUrl: string;
  source: string;
  viewers: number;
}

export interface SportInfo {
  id: string;
  name: string;
  icon: string;
  gradient: string;
}

export interface StreamReport {
  id: number;
  stream_url: string;
  match_title: string;
  issue: string;
  source: string;
  created_at: string;
}
