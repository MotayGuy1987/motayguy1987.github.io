import type { SportInfo } from './types';

export const SPORTS: SportInfo[] = [
  { id: 'all', name: 'All', icon: 'Trophy', gradient: 'from-amber-500 to-orange-600' },
  { id: 'football', name: 'Football', icon: 'Circle', gradient: 'from-green-500 to-emerald-600' },
  { id: 'cricket', name: 'Cricket', icon: 'Circle', gradient: 'from-teal-500 to-cyan-600' },
];

// Only these sports are shown across the site
export const ACTIVE_SPORTS = ['football', 'cricket'];

export function isSportActive(sportId: string): boolean {
  return ACTIVE_SPORTS.includes(sportId);
}

export function getSportInfo(sportId: string): SportInfo {
  return SPORTS.find(s => s.id === sportId) || SPORTS[0];
}

export function getSportGradient(sportId: string): string {
  return getSportInfo(sportId).gradient;
}

export function getSportName(sportId: string): string {
  return getSportInfo(sportId).name;
}
