import { useEffect, useState, useMemo, useCallback } from 'react';
import { useSearchParams } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Radio, Search, Loader2, Filter, X, Flame } from 'lucide-react';
import type { Match } from '../lib/types';
import { SPORTS } from '../lib/sports';
import MatchCard from '../components/MatchCard';
import ParticleCanvas from '../components/ParticleCanvas';

type Tab = 'live' | 'upcoming' | 'all';

export default function Home() {
  const [matches, setMatches] = useState<Match[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [sport, setSport] = useState('all');
  const [tab, setTab] = useState<Tab>('live');
  const [searchParams] = useSearchParams();
  const searchQuery = searchParams.get('q') || '';
  const [localSearch, setLocalSearch] = useState('');
  const [hasFullDataset, setHasFullDataset] = useState(false);

  // Fetch matches — initial load is fast (live+popular), "All" tab loads full dataset
  const fetchMatches = useCallback(async (loadAll = false) => {
    try {
      const params = new URLSearchParams();
      if (loadAll) params.set('all', 'true');
      const res = await fetch(`/api/matches${params ? '?' + params : ''}`);
      if (!res.ok) throw new Error('Failed to fetch matches');
      const data = await res.json();
      // Handle debug wrapper format if present
      const arr = Array.isArray(data) ? data : (data.matches || []);
      setMatches(arr);
      if (loadAll) setHasFullDataset(true);
      setError('');
    } catch (err: any) {
      setError(err.message || 'Failed to load matches');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    setLoading(true);
    fetchMatches();
    // Poll for live updates every 60s (keep same mode)
    const interval = setInterval(() => fetchMatches(hasFullDataset), 60000);
    return () => clearInterval(interval);
  }, [fetchMatches, hasFullDataset]);

  // When switching to "All" tab, load full dataset if not already loaded
  const handleTabChange = (newTab: Tab): void => {
    setTab(newTab);
    if (newTab === 'all' && !hasFullDataset) {
      setLoading(true);
      fetchMatches(true);
    }
  };

  // INSTANT client-side filtering — no re-fetch needed when switching tabs/sports
  const filteredMatches = useMemo(() => {
    return matches.filter((m) => {
      // Sport filter — "all" shows only football & cricket (the main focus)
      if (sport === 'all' && m.sport !== 'football' && m.sport !== 'cricket') return false;
      if (sport !== 'all' && m.sport !== sport) return false;

      // Tab filter
      if (tab === 'live' && !m.live) return false;
      if (tab === 'upcoming' && m.live) return false;

      // Search filter
      const q = (searchQuery || localSearch).toLowerCase().trim();
      if (q) {
        const haystack = `${m.title} ${m.homeTeam.name} ${m.awayTeam.name} ${m.league} ${m.sport}`.toLowerCase();
        if (!haystack.includes(q)) return false;
      }
      return true;
    });
  }, [matches, sport, tab, searchQuery, localSearch]);

  const liveCount = matches.filter(m => m.live).length;
  // Featured = highest prestige matches (World Cup, Champions League, etc.)
  // Score combines league prestige, team popularity, live status & source count
  const featuredMatches = [...filteredMatches]
    .sort((a, b) => (b.featuredScore || 0) - (a.featuredScore || 0))
    .filter(m => (m.featuredScore || 0) > 0)
    .slice(0, 4);
  const featuredIds = new Set(featuredMatches.map(m => m.uid));
  const regularMatches = filteredMatches.filter(m => !featuredIds.has(m.uid));

  return (
    <div className="min-h-screen bg-slate-950">
      {/* Hero section */}
      <div className="relative overflow-hidden border-b border-white/5">
        <div className="absolute inset-0 bg-gradient-to-br from-cyan-950/40 via-slate-950 to-purple-950/30" />
        <ParticleCanvas colors={['#22d3ee', '#3b82f6', '#a855f7', '#ec4899']} count={50} intensity={0.8} />
        <div className="relative mx-auto max-w-7xl px-4 py-10 sm:py-14">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center"
          >
            <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-4 py-1.5 text-xs font-medium text-cyan-300 backdrop-blur-sm">
              <Radio className="h-3.5 w-3.5 animate-pulse" />
              {liveCount} {liveCount === 1 ? 'match' : 'matches'} live now
            </div>
            <h1 className="text-4xl font-black tracking-tight text-white sm:text-5xl md:text-6xl">
              Football & Cricket <span className="bg-gradient-to-r from-cyan-400 via-blue-400 to-purple-400 bg-clip-text text-transparent">Ad-Free</span>
            </h1>
            <p className="mx-auto mt-3 max-w-xl text-sm text-slate-400 sm:text-base">
              Live football & cricket streams aggregated from multiple sources — WatchFooty & Streamed.pk. Zero popups, zero redirects.
            </p>
          </motion.div>
        </div>
      </div>

      <div className="mx-auto max-w-7xl px-4 py-6">
        {/* Sport filter pills */}
        <div className="mb-5 flex flex-wrap gap-2">
          {SPORTS.map((s) => (
            <button
              key={s.id}
              onClick={() => setSport(s.id)}
              className={`rounded-full px-3.5 py-1.5 text-xs font-semibold transition-all ${
                sport === s.id
                  ? `bg-gradient-to-r ${s.gradient} text-white shadow-lg`
                  : 'border border-white/10 bg-white/5 text-slate-400 hover:bg-white/10 hover:text-white'
              }`}
            >
              {s.name}
            </button>
          ))}
        </div>

        {/* Tabs + search */}
        <div className="mb-6 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex gap-1 rounded-xl border border-white/10 bg-slate-900/60 p-1">
            {([
              { id: 'live', label: 'Live Now', icon: Radio },
              { id: 'upcoming', label: 'Upcoming', icon: null },
              { id: 'all', label: 'All', icon: null },
            ] as const).map((t) => (
              <button
                key={t.id}
                onClick={() => handleTabChange(t.id)}
                className={`flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-semibold transition-all ${
                  tab === t.id
                    ? 'bg-white/10 text-white'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {t.icon && <t.icon className={`h-3.5 w-3.5 ${tab === t.id ? 'text-red-400' : ''}`} />}
                {t.label}
              </button>
            ))}
          </div>

          <div className="relative flex-1 sm:max-w-xs">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" />
            <input
              type="text"
              value={localSearch}
              onChange={(e) => setLocalSearch(e.target.value)}
              placeholder="Filter matches..."
              className="w-full rounded-xl border border-white/10 bg-slate-900/60 py-2 pl-10 pr-9 text-sm text-white placeholder-slate-500 outline-none focus:border-cyan-500/50"
            />
            {localSearch && (
              <button
                onClick={() => setLocalSearch('')}
                className="absolute right-2 top-1/2 -translate-y-1/2 rounded p-1 text-slate-400 hover:text-white"
              >
                <X className="h-3.5 w-3.5" />
              </button>
            )}
          </div>
        </div>

        {/* Loading */}
        {loading ? (
          <div className="flex flex-col items-center justify-center py-20">
            <Loader2 className="h-10 w-10 animate-spin text-cyan-400" />
            <p className="mt-3 text-sm text-slate-400">Fetching live matches...</p>
          </div>
        ) : error ? (
          <div className="flex flex-col items-center justify-center py-20">
            <p className="text-sm text-red-400">{error}</p>
            <button onClick={() => fetchMatches(hasFullDataset)} className="mt-3 rounded-lg bg-white/10 px-4 py-2 text-sm text-white hover:bg-white/20">
              Retry
            </button>
          </div>
        ) : filteredMatches.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 text-center">
            <Filter className="h-10 w-10 text-slate-600" />
            <p className="mt-3 text-sm text-slate-400">No matches found for this filter.</p>
            <p className="mt-1 text-xs text-slate-500">Try a different sport or check back later.</p>
          </div>
        ) : (
          <div className="space-y-8">
            {/* Featured matches — highest prestige competitions */}
            {featuredMatches.length > 0 && (
              <div>
                <div className="mb-4 flex items-center gap-2">
                  <Flame className="h-5 w-5 text-amber-400" />
                  <h2 className="text-lg font-bold text-white">Featured Matches</h2>
                </div>
                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
                  <AnimatePresence mode="popLayout">
                    {featuredMatches.map((match, i) => (
                      <MatchCard key={match.uid} match={match} index={i} />
                    ))}
                  </AnimatePresence>
                </div>
              </div>
            )}

            {/* Regular matches */}
    {regularMatches.length > 0 && (
              <div>
                {featuredMatches.length > 0 && (
                  <div className="mb-4 flex items-center gap-2">
                    <h2 className="text-lg font-bold text-white">All Matches</h2>
                    <span className="rounded-full bg-white/5 px-2 py-0.5 text-xs text-slate-400">{regularMatches.length}</span>
                  </div>
                )}
                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
                  <AnimatePresence mode="popLayout">
                    {regularMatches.map((match, i) => (
                      <MatchCard key={match.uid} match={match} index={i} />
                    ))}
                  </AnimatePresence>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
