import { useEffect, useState, useCallback, useRef } from 'react';
import { useParams, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  ArrowLeft, Radio, Clock, Loader2, AlertCircle, Shield,
  Flag, ChevronRight, Signal, Eye, RefreshCw
} from 'lucide-react';
import type { Match, StreamedStream } from '../lib/types';
import TeamLogo from '../components/TeamLogo';
import ParticleCanvas from '../components/ParticleCanvas';
import IframePlayer from '../components/IframePlayer';
import { getSportGradient, getSportName } from '../lib/sports';

interface SourceOption {
  id: string;
  label: string;
  type: 'watchfooty' | 'streamed';
  url: string;
  meta: string;
  quality?: string;
  language?: string;
  ads?: boolean;
  viewers?: number;
  provider?: string;
}

function formatTime(ts: number) {
  return new Date(ts).toLocaleString([], {
    weekday: 'short', month: 'short', day: 'numeric',
    hour: '2-digit', minute: '2-digit',
  });
}

// Pretty labels for WatchFooty stream providers
const PROVIDER_LABELS: Record<string, string> = {
  hd: 'HD Main',
  delta: 'Delta HD',
  echo: 'Echo HD',
  platinum: 'Platinum HD',
  pro: 'Pro HD',
  easy: 'Easy HD',
  sigma: 'Sigma HD',
  prime: 'Prime HD',
  regular: 'SD Backup',
};

export default function MatchPlayer() {
  const { uid } = useParams<{ uid: string }>();
  const [match, setMatch] = useState<Match | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [sources, setSources] = useState<SourceOption[]>([]);
  const [activeSource, setActiveSource] = useState<SourceOption | null>(null);
  const [loadingSources, setLoadingSources] = useState(false);
  const [reporting, setReporting] = useState(false);
  const [reportSent, setReportSent] = useState(false);
  const [autoAdvanced, setAutoAdvanced] = useState(false);
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const deadSourcesRef = useRef<Set<string>>(new Set());

  const fetchMatch = useCallback(async () => {
    try {
      const res = await fetch(`/api/matches?id=${encodeURIComponent(uid || '')}`);
      if (!res.ok) throw new Error('Failed to fetch match');
      const data = await res.json();
      if (data.error) throw new Error(data.error);
      setMatch(data);
      setError('');
    } catch (err: any) {
      setError(err.message || 'Failed to load match');
    } finally {
      setLoading(false);
    }
  }, [uid]);

  useEffect(() => {
    setLoading(true);
    fetchMatch();
    pollRef.current = setInterval(fetchMatch, 60000);
    return () => { if (pollRef.current) clearInterval(pollRef.current); };
  }, [fetchMatch]);

  // Build source list once match is loaded
  const buildSources = useCallback(async () => {
    if (!match) return;
    setLoadingSources(true);
    const opts: SourceOption[] = [];

    // 1. WatchFooty streams — already deduped by provider server-side
    if (match.watchfooty?.streams.length) {
      match.watchfooty.streams.forEach((s, i) => {
        const provider = s.provider || 'stream';
        const label = PROVIDER_LABELS[provider] || `WatchFooty ${provider}`;
        opts.push({
          id: `wf-${s.id}-${i}`,
          label,
          type: 'watchfooty',
          url: s.url,
          meta: `${s.quality || 'HD'} · ${s.language || 'EN'}`,
          quality: s.quality,
          language: s.language,
          ads: s.ads,
          provider,
        });
      });
    }

    // 2. Streamed.pk streams (embed.st) — fetch resolved streams
    if (match.streamed?.sources.length) {
      try {
        const spResults = await Promise.all(
          match.streamed.sources.map(src =>
            fetch(`/api/streamed-streams?source=${src.source}&id=${encodeURIComponent(src.id)}`)
              .then(r => r.json())
              .then((streams: StreamedStream[]) => streams.map(s => ({ ...s, parentSource: src.source })))
              .catch(() => [])
          )
        );
        const allSpStreams = spResults.flat();
        allSpStreams.sort((a, b) => {
          if (a.hd !== b.hd) return a.hd ? -1 : 1;
          return (b.viewers || 0) - (a.viewers || 0);
        });
        allSpStreams.forEach((s, i) => {
          opts.push({
            id: `sp-${s.id}-${s.streamNo}`,
            label: `Streamed #${i + 1}`,
            type: 'streamed',
            url: s.embedUrl,
            meta: `${s.hd ? 'HD' : 'SD'} · ${s.language}`,
            language: s.language,
            viewers: s.viewers,
          });
        });
      } catch (e) {
        console.error('Failed to fetch streamed sources:', e);
      }
    }

    setSources(opts);
    if (opts.length > 0 && !activeSource) {
      setActiveSource(opts[0]);
    }
    setLoadingSources(false);
  }, [match]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (match && sources.length === 0 && !loadingSources) {
      buildSources();
    }
  }, [match]); // eslint-disable-line react-hooks/exhaustive-deps

  // Auto-advance: mark current source as dead and try the next one
  const handleDeadStream = useCallback(() => {
    if (!activeSource) return;
    deadSourcesRef.current.add(activeSource.id);
    // Find next source that isn't dead
    const nextSource = sources.find(s => !deadSourcesRef.current.has(s.id));
    if (nextSource && nextSource.id !== activeSource.id) {
      setAutoAdvanced(true);
      setActiveSource(nextSource);
      setTimeout(() => setAutoAdvanced(false), 5000);
    }
  }, [activeSource, sources]);

  const handleSelectSource = (src: SourceOption) => {
    setActiveSource(src);
    setReportSent(false);
    setAutoAdvanced(false);
  };

  const handleReport = async () => {
    if (!activeSource || reporting) return;
    setReporting(true);
    try {
      await fetch('/api/reports', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          stream_url: activeSource.url,
          match_title: match?.title || '',
          issue: 'Broken or not playing',
          source: activeSource.type,
        }),
      });
      setReportSent(true);
      setTimeout(() => setReportSent(false), 4000);
    } catch (e) {
      console.error('Report failed:', e);
    } finally {
      setReporting(false);
    }
  };

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-slate-950">
        <Loader2 className="h-10 w-10 animate-spin text-cyan-400" />
      </div>
    );
  }

  if (error || !match) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center gap-4 bg-slate-950">
        <AlertCircle className="h-10 w-10 text-red-400" />
        <p className="text-sm text-slate-400">{error || 'Match not found'}</p>
        <Link to="/" className="rounded-lg bg-white/10 px-4 py-2 text-sm text-white hover:bg-white/20">
          Back to Home
        </Link>
      </div>
    );
  }

  const gradient = getSportGradient(match.sport);

  return (
    <div className="min-h-screen bg-slate-950">
      {/* Match header banner */}
      <div className="relative overflow-hidden border-b border-white/5">
        <div className={`absolute inset-0 bg-gradient-to-br ${gradient} opacity-20`} />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/60 to-transparent" />
        <ParticleCanvas colors={['#22d3ee', '#3b82f6', '#a855f7', '#ec4899']} count={40} intensity={0.7} />

        <div className="relative mx-auto max-w-7xl px-4 py-6">
          <Link to="/" className="mb-4 inline-flex items-center gap-1.5 text-sm text-slate-400 transition-colors hover:text-white">
            <ArrowLeft className="h-4 w-4" /> Back
          </Link>

          <div className="flex flex-col items-center gap-4 sm:flex-row sm:items-center sm:justify-between">
            {/* Teams */}
            <div className="flex items-center gap-4 sm:gap-8">
              <div className="flex flex-col items-center gap-2">
                <motion.div animate={{ y: [0, -8, 0] }} transition={{ duration: 4, repeat: Infinity, ease: 'easeInOut' }}>
                  <TeamLogo src={match.homeTeam.logo} name={match.homeTeam.name} className="h-16 w-16 sm:h-20 sm:w-20" />
                </motion.div>
                <span className="max-w-[100px] text-center text-sm font-bold text-white">{match.homeTeam.name || 'TBD'}</span>
              </div>

              <div className="flex flex-col items-center">
                {match.live ? (
                  <>
                    <div className="flex items-center gap-3">
                      <span className="text-3xl font-black text-white sm:text-4xl">{match.homeScore ?? 0}</span>
                      <span className="text-xl font-bold text-slate-500">-</span>
                      <span className="text-3xl font-black text-white sm:text-4xl">{match.awayScore ?? 0}</span>
                    </div>
                    {match.minute && (
                      <span className="mt-1 flex items-center gap-1 text-xs font-semibold text-red-400">
                        <Radio className="h-3 w-3 animate-pulse" /> {match.minute}
                      </span>
                    )}
                  </>
                ) : (
                  <div className="rounded-xl bg-white/5 px-4 py-2 text-center">
                    <div className="text-xs font-bold uppercase tracking-widest text-slate-400">VS</div>
                  </div>
                )}
              </div>

              <div className="flex flex-col items-center gap-2">
                <motion.div animate={{ y: [0, -8, 0] }} transition={{ duration: 4, repeat: Infinity, ease: 'easeInOut', delay: 2 }}>
                  <TeamLogo src={match.awayTeam.logo} name={match.awayTeam.name} className="h-16 w-16 sm:h-20 sm:w-20" />
                </motion.div>
                <span className="max-w-[100px] text-center text-sm font-bold text-white">{match.awayTeam.name || 'TBD'}</span>
              </div>
            </div>

            {/* Match info */}
            <div className="flex flex-col items-center gap-1 text-center sm:items-end sm:text-right">
              {match.live ? (
                <div className="flex items-center gap-1.5 rounded-full bg-red-500/90 px-3 py-1 text-xs font-bold uppercase tracking-wider text-white">
                  <Radio className="h-3 w-3 animate-pulse" /> Live
                </div>
              ) : (
                <div className="flex items-center gap-1.5 rounded-full bg-slate-700/80 px-3 py-1 text-xs font-bold uppercase tracking-wider text-slate-300">
                  <Clock className="h-3 w-3" /> {formatTime(match.date)}
                </div>
              )}
              <span className="text-sm font-semibold text-white">{match.league || getSportName(match.sport)}</span>
              <span className="text-xs text-slate-400">{getSportName(match.sport)}</span>
            </div>
          </div>
        </div>
      </div>

      <div className="mx-auto max-w-7xl px-4 py-6">
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
          {/* Player */}
          <div className="lg:col-span-2">
            {/* Auto-advance notification */}
            {autoAdvanced && (
              <div className="mb-3 flex items-center gap-2 rounded-lg border border-amber-500/30 bg-amber-500/10 px-3 py-2 text-xs text-amber-300">
                <RefreshCw className="h-3.5 w-3.5 animate-spin" />
                Source wasn't playing — automatically switched to the next available stream.
              </div>
            )}

            {activeSource ? (
              <IframePlayer
                key={activeSource.id}
                src={`/api/wf-embed?url=${encodeURIComponent(activeSource.url)}`}
                title={match.title}
                onDeadStream={handleDeadStream}
                sandbox={false}
              />
            ) : loadingSources ? (
              <div className="flex aspect-video w-full flex-col items-center justify-center rounded-xl bg-black">
                <Loader2 className="h-10 w-10 animate-spin text-cyan-400" />
                <p className="mt-3 text-sm text-slate-400">Resolving streams...</p>
              </div>
            ) : (
              <div className="flex aspect-video w-full flex-col items-center justify-center gap-3 rounded-xl bg-black">
                <AlertCircle className="h-10 w-10 text-slate-600" />
                <p className="text-sm text-slate-400">No streams available for this match.</p>
                <p className="text-xs text-slate-500">It may not have started yet or no source has it.</p>
              </div>
            )}

            {/* Report button */}
            <div className="mt-3 flex items-center justify-between">
              <div className="flex items-center gap-2 text-xs text-slate-500">
                {activeSource?.type === 'streamed' && (
                  <span className="flex items-center gap-1 text-emerald-400">
                    <Shield className="h-3.5 w-3.5" /> Popup & redirect ads blocked by sandbox
                  </span>
                )}
                {activeSource?.type === 'watchfooty' && (
                  <span className="flex items-center gap-1 text-emerald-400">
                    <Shield className="h-3.5 w-3.5" /> Ad scripts stripped server-side
                  </span>
                )}
              </div>
              <button
                onClick={handleReport}
                disabled={reporting || !activeSource}
                className="flex items-center gap-1.5 rounded-lg border border-white/10 bg-white/5 px-3 py-1.5 text-xs font-medium text-slate-300 transition-colors hover:bg-white/10 disabled:opacity-50"
              >
                <Flag className="h-3.5 w-3.5" />
                {reportSent ? 'Reported!' : reporting ? 'Reporting...' : 'Report Broken'}
              </button>
            </div>
          </div>

          {/* Source picker */}
          <div className="lg:col-span-1">
            <div className="sticky top-20 rounded-2xl border border-white/10 bg-slate-900/60 p-4 backdrop-blur-xl">
              <div className="mb-3 flex items-center justify-between">
                <h3 className="flex items-center gap-2 text-sm font-bold text-white">
                  <Signal className="h-4 w-4 text-cyan-400" /> Sources
                </h3>
                <span className="rounded-full bg-white/5 px-2 py-0.5 text-xs text-slate-400">{sources.length}</span>
              </div>

              {loadingSources ? (
                <div className="flex items-center justify-center py-8">
                  <Loader2 className="h-6 w-6 animate-spin text-cyan-400" />
                </div>
              ) : sources.length === 0 ? (
                <div className="py-8 text-center">
                  <p className="mt-2 text-xs text-slate-500">No sources found</p>
                </div>
              ) : (
                <div className="max-h-[60vh] space-y-2 overflow-y-auto pr-1">
                  {sources.map((src) => {
                    const isDead = deadSourcesRef.current.has(src.id);
                    return (
                      <button
                        key={src.id}
                        onClick={() => handleSelectSource(src)}
                        className={`w-full rounded-xl border p-3 text-left transition-all ${
                          activeSource?.id === src.id
                            ? 'border-cyan-500/50 bg-cyan-500/10'
                            : isDead
                            ? 'border-red-500/20 bg-red-500/5 opacity-50'
                            : 'border-white/10 bg-white/5 hover:border-white/20 hover:bg-white/10'
                        }`}
                      >
                        <div className="flex items-start justify-between gap-2">
                          <div className="min-w-0 flex-1">
                            <div className="flex items-center gap-1.5">
                              <span className={`truncate text-sm font-semibold ${isDead ? 'text-slate-500 line-through' : 'text-white'}`}>{src.label}</span>
                              {src.type === 'streamed' && <Shield className="h-3 w-3 shrink-0 text-emerald-400" />}
                              {src.type === 'watchfooty' && src.provider === 'hd' && (
                                <span className="rounded bg-cyan-500/20 px-1 py-0.5 text-[8px] font-bold uppercase text-cyan-300">Best</span>
                              )}
                            </div>
                            <div className="mt-0.5 flex items-center gap-2 text-[11px] text-slate-400">
                              <span>{src.meta}</span>
                              {src.viewers != null && (
                                <span className="flex items-center gap-0.5">
                                  <Eye className="h-3 w-3" /> {src.viewers.toLocaleString()}
                                </span>
                              )}
                              {isDead && <span className="text-red-400">No video</span>}
                            </div>
                          </div>
                          {activeSource?.id === src.id && (
                            <ChevronRight className="h-4 w-4 shrink-0 text-cyan-400" />
                          )}
                        </div>
                      </button>
                    );
                  })}
                </div>
              )}

              {/* Source legend */}
              <div className="mt-3 space-y-1.5 border-t border-white/5 pt-3 text-[10px] text-slate-500">
                <div className="flex items-center gap-1.5">
                  <Shield className="h-3 w-3 text-emerald-400" /> Streamed = sandboxed iframe (ads blocked)
                </div>
                <div className="flex items-center gap-1.5">
                  <Shield className="h-3 w-3 text-cyan-400" /> WatchFooty = ad scripts stripped
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
