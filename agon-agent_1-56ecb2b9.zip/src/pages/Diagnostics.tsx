import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import {
  CheckCircle2, XCircle, AlertTriangle, Loader2,
  Server, Globe, Shield, Radio, Layers, Bug, RefreshCw,
  Zap
} from 'lucide-react';

interface DiagResult {
  wfApi?: any;
  wfApiError?: string;
  wfApiNote?: string;
  wfEmbedDirect?: any;
  nestedEmbed?: any;
  ourProxy?: any;
  nestedProxy?: any;
  spApi?: any;
  spApiError?: string;
  spStreamResolve?: any;
  embedStDirect?: any;
  verdict?: any;
}

function StatusIcon({ status }: { status: 'ok' | 'warn' | 'fail' | 'loading' }) {
  switch (status) {
    case 'ok': return <CheckCircle2 className="h-5 w-5 text-emerald-400" />;
    case 'warn': return <AlertTriangle className="h-5 w-5 text-amber-400" />;
    case 'fail': return <XCircle className="h-5 w-5 text-red-400" />;
    case 'loading': return <Loader2 className="h-5 w-5 animate-spin text-cyan-400" />;
  }
}

function StatusBadge({ label, status }: { label: string; status: 'ok' | 'warn' | 'fail' | 'loading' }) {
  const colors = {
    ok: 'border-emerald-500/30 bg-emerald-500/10 text-emerald-300',
    warn: 'border-amber-500/30 bg-amber-500/10 text-amber-300',
    fail: 'border-red-500/30 bg-red-500/10 text-red-300',
    loading: 'border-cyan-500/30 bg-cyan-500/10 text-cyan-300',
  };
  return (
    <div className={`flex items-center gap-2 rounded-lg border px-3 py-2 ${colors[status]}`}>
      <StatusIcon status={status} />
      <span className="text-sm font-medium">{label}</span>
    </div>
  );
}

function DetailRow({ label, value, bad = false }: { label: string; value: string | number | boolean; bad?: boolean }) {
  return (
    <div className="flex items-start justify-between gap-4 py-1.5 border-b border-white/5 last:border-0">
      <span className="text-xs text-slate-400 shrink-0">{label}</span>
      <span className={`text-xs font-mono break-all text-right ${bad ? 'text-red-400' : 'text-slate-200'}`}>
        {typeof value === 'boolean' ? (value ? '\u2705 Yes' : '\u274C No') : String(value)}
      </span>
    </div>
  );
}

export default function Diagnostics() {
  const [data, setData] = useState<DiagResult | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const runDiagnostics = async () => {
    setLoading(true);
    setError('');
    try {
      const res = await fetch('/api/diagnostics');
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const json = await res.json();
      setData(json);
    } catch (e: any) {
      setError(e.message || 'Failed to run diagnostics');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { runDiagnostics(); }, []);

  const v = data?.verdict;

  return (
    <div className="min-h-screen bg-slate-950">
      {/* Header */}
      <div className="border-b border-white/10 bg-slate-900/50">
        <div className="mx-auto max-w-6xl px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Bug className="h-7 w-7 text-cyan-400" />
              <div>
                <h1 className="text-xl font-bold text-white">Pipeline Diagnostics</h1>
                <p className="text-xs text-slate-400">Traces every layer of the streaming pipeline end-to-end</p>
              </div>
            </div>
            <button
              onClick={runDiagnostics}
              disabled={loading}
              className="flex items-center gap-2 rounded-xl border border-white/10 bg-white/5 px-4 py-2 text-sm font-medium text-slate-300 transition-colors hover:bg-white/10 disabled:opacity-50"
            >
              <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
              Re-run
            </button>
          </div>
        </div>
      </div>

      <div className="mx-auto max-w-6xl space-y-6 px-4 py-8">
        {error && (
          <div className="rounded-xl border border-red-500/30 bg-red-500/10 p-4 text-sm text-red-300">
            Error: {error}
          </div>
        )}

        {loading && !data && (
          <div className="flex flex-col items-center py-20">
            <Loader2 className="h-10 w-10 animate-spin text-cyan-400" />
            <p className="mt-3 text-sm text-slate-400">Running full pipeline diagnostic...</p>
          </div>
        )}

        {!loading && data && (
          <>
            {/* Verdict Summary */}
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="rounded-2xl border border-white/10 bg-slate-900/60 p-5">
              <h2 className="mb-4 flex items-center gap-2 text-sm font-bold uppercase tracking-wider text-slate-300">
                <Layers className="h-4 w-4" /> System Health &mdash; {v?.timestamp || ''}
              </h2>
              <div className="grid grid-cols-2 gap-3 sm:grid-cols-4 lg:grid-cols-8">
                <StatusBadge label="WF API" status={v?.wfApiOk ? 'ok' : 'fail'} />
                <StatusBadge label="WF Embed" status={
                  v?.wfEmbedIs500 ? 'fail' :
                  v?.wfEmbedOk ? 'ok' : 'warn'
                } />
                <StatusBadge label="Nested Iframe" status={v?.wfNestedOk ? 'ok' : v?.nestedEmbed ? 'fail' : 'warn'} />
                <StatusBadge label="Our Proxy" status={v?.wfProxyOk ? 'ok' : 'fail'} />
                <StatusBadge label="Ad Shield" status={v?.wfShieldActive ? 'ok' : 'warn'} />
                <StatusBadge label="SP API" status={v?.spApiOk ? 'ok' : 'fail'} />
                <StatusBadge label="SP Streams" status={v?.spStreamOk ? 'ok' : 'fail'} />
                <StatusBadge label="embed.st" status={v?.embedStOk ? 'ok' : 'fail'} />
              </div>
            </motion.div>

            {/* Layer 1: WatchFooty API */}
            <DiagCard title="Layer 1: WatchFooty API" icon={<Globe className="h-5 w-5" />} ok={!!data.wfApi} error={data.wfApiError}>
              {data.wfApi && (
                <>
                  <DetailRow label="HTTP Status" value={data.wfApi.status} />
                  <DetailRow label="Live Matches Found" value={data.wfApi.count} />
                  <DetailRow label="Response Time" value={`${data.wfApi.elapsedMs}ms`} />
                  {data.wfApi.sampleMatches.map((m: any, i: number) => (
                    <div key={i} className="mt-3 rounded-lg border border-white/5 bg-black/20 p-3">
                      <DetailRow label="Match" value={m.title} />
                      <DetailRow label="Sport / League" value={`${m.sport} \u00b7 ${m.league}`} />
                      <DetailRow label="Streams Available" value={m.streamCount} />
                      <DetailRow label="First Stream URL" value={m.firstStreamUrl} />
                    </div>
                  ))}
                </>
              )}
              {data.wfApiNote && <p className="mt-2 text-xs text-amber-300">{data.wfApiNote}</p>}
            </DiagCard>

            {/* Layer 2: WF Embed Direct */}
            <DiagCard title="Layer 2: WF Embed Page (sportsembed.su)" icon={<Server className="h-5 w-5" />} ok={data.wfEmbedDirect?.ok && data.wfEmbedDirect?.size > 500} error={!data.wfEmbedDirect ? data.wfApiNote || 'No test match available' : undefined}>
              {data.wfEmbedDirect && (
                <>
                  <DetailRow label="URL" value={(data.wfEmbedDirect.url || '').slice(0, 100)} />
                  <DetailRow label="HTTP Status" value={data.wfEmbedDirect.status} bad={data.wfEmbedDirect.status >= 400} />
                  <DetailRow label="Body Size" value={`${data.wfEmbedDirect.size} bytes`} bad={data.wfEmbedDirect.size < 100} />
                  <DetailRow label="Response Time" value={`${data.wfEmbedDirect.elapsedMs}ms`} />
                  <DetailRow label="Has Video iframe" value={data.wfEmbedDirect.hasIframe} />
                  <DetailRow label="Ad Scripts Present" value={data.wfEmbedDirect.hasAdScript} bad={data.wfEmbedDirect.hasAdScript} />
                  <DetailRow label="Video Player Detected" value={data.wfEmbedDirect.hasVideoPlayer} />
                  <DetailRow label="Nested iframe src" value={data.wfEmbedDirect.nestedIframeSrc || '(none)'} />
                  <DetailRow label="X-Frame-Options" value={data.wfEmbedDirect.frameBlockingHeaders.length > 0 ? data.wfEmbedDirect.frameBlockingHeaders.join(', ') : 'NONE \u2705'} />

                  {data.wfEmbedDirect.is500Error && (
                    <div className="mt-3 rounded-lg border border-red-500/30 bg-red-500/10 p-4 space-y-2">
                      <p className="text-xs font-bold text-red-300">\u26A0\uFE0F sportsembed.su returned HTTP 500!</p>
                      <p className="text-xs text-red-400 font-mono">{data.wfEmbedDirect.errorBody}</p>
                      <div className="rounded-lg bg-red-500/10 p-3 mt-2">
                        <p className="text-[11px] text-red-300 leading-relaxed">
                          <strong>What this means:</strong> The embed page for this match has been cleaned up from sportsembed.su's server.
                          This happens when a match has ended. Only <strong>current live or upcoming matches</strong> have working embed pages.
                          Try clicking on a match that is currently live or hasn't started yet.
                        </p>
                      </div>
                    </div>
                  )}
                </>
              )}
            </DiagCard>

            {/* Layer 3: Nested iframe (embedindia.st) */}
            <DiagCard title="Layer 3: Nested Embed (embedindia.st)" icon={<Server className="h-5 w-5" />} ok={data.nestedEmbed?.ok && data.nestedEmbed?.size > 1000} error={!data.nestedEmbed ? 'No nested iframe found in layer 2' : undefined}>
              {data.nestedEmbed && (
                <>
                  <DetailRow label="URL" value={(data.nestedEmbed.url || '').slice(0, 100)} />
                  <DetailRow label="HTTP Status" value={data.nestedEmbed.status} bad={data.nestedEmbed.status >= 400} />
                  <DetailRow label="Body Size" value={`${data.nestedEmbed.size} bytes`} />
                  <DetailRow label="Response Time" value={`${data.nestedEmbed.elapsedMs}ms`} />
                  <DetailRow label="JWPlayer present" value={data.nestedEmbed.hasJWPlayer} />
                  <DetailRow label="VideoJS present" value={data.nestedEmbed.hasVideoJS} />
                  <DetailRow label="Clappr present" value={data.nestedEmbed.hasClappr} />
                  <DetailRow label="file:/sources: config" value={data.nestedEmbed.hasFileConfig} />
                  <DetailRow label="M3U8 URLs found" value={data.nestedEmbed.m3u8Urls.length > 0 ? data.nestedEmbed.m3u8Urls.join(', ') : '(none)'} />
                  <DetailRow label="Popup scripts" value={data.nestedEmbed.hasPopupScripts} bad={data.nestedEmbed.hasPopupScripts} />
                  <DetailRow label="X-Frame-Options" value={data.nestedEmbed.frameBlockingHeaders.length > 0 ? data.nestedEmbed.frameBlockingHeaders.join(', ') : 'NONE \u2705'} />
                </>
              )}
            </DiagCard>

            {/* Layer 4: Our Proxy */}
            <DiagCard title="Layer 4: Our Ad-Cleaning Proxy (/api/wf-embed)" icon={<Shield className="h-5 w-5" />} ok={data.ourProxy?.ok && data.ourProxy?.size > 500 && data.ourProxy.videoIframePreserved}>
              {data.ourProxy && (
                <>
                  <DetailRow label="HTTP Status" value={data.ourProxy.status} bad={data.ourProxy.status >= 400} />
                  <DetailRow label="Body Size" value={`${data.ourProxy.size} bytes`} bad={data.ourProxy.size < 100} />
                  <DetailRow label="Response Time" value={`${data.ourProxy.elapsedMs}ms`} />
                  <DetailRow label="Ad Scripts Stripped" value={data.ourProxy.adStripped} />
                  <DetailRow label="Video iframe Preserved" value={data.ourProxy.videoIframePreserved} />
                  <DetailRow label="<Zap> Ad Shield Injected" value={data.ourProxy.shieldInjected} />
                  <DetailRow label="<base> Tag Set" value={data.ourProxy.baseTagInjected} />
                  <DetailRow label="Is Error Response" value={data.ourProxy.isProxyError} bad={data.ourProxy.isProxyError} />
                  {data.ourProxy.isProxyError && (
                    <div className="mt-2 rounded-lg border border-red-500/30 bg-red-500/10 p-3">
                      <p className="text-xs text-red-300 font-mono break-all">{(data.ourProxy.body || '').slice(0, 300)}</p>
                    </div>
                  )}
                </>
              )}
            </DiagCard>

            {/* Layer 4b: Nested proxy */}
            <DiagCard title="Layer 4b: Nested Iframe Through Our Proxy" icon={<Shield className="h-5 w-5" />} ok={data.nestedProxy?.hasContent} error={!data.nestedProxy ? 'No nested URL from layer 3' : undefined}>
              {data.nestedProxy && (
                <>
                  <DetailRow label="HTTP Status" value={data.nestedProxy.status} />
                  <DetailRow label="Body Size" value={`${data.nestedProxy.size} bytes`} />
                  <DetailRow label="Has Content (>500B)" value={data.nestedProxy.hasContent} />
                  <DetailRow label="Shield in Nested Too?" value={data.nestedProxy.shieldInjected} />
                </>
              )}
            </DiagCard>

            {/* Streamed.pk section */}
            <DiagCard title="Layer 5: Streamed.pk API" icon={<Globe className="h-5 w-5" />} ok={!!data.spApi} error={data.spApiError}>
              {data.spApi && (
                <>
                  <DetailRow label="HTTP Status" value={data.spApi.status} />
                  <DetailRow label="Live Matches" value={data.spApi.count} />
                  <DetailRow label="Response Time" value={`${data.spApi.elapsedMs}ms`} />
                  {data.spApi.sampleMatches.map((m: any, i: number) => (
                    <div key={i} className="mt-2 rounded-lg border border-white/5 bg-black/20 p-3">
                      <DetailRow label="Match" value={m.title} />
                      <DetailRow label="Category" value={m.category} />
                      <DetailRow label="Popular" value={m.popular} />
                      <DetailRow label="Sources" value={JSON.stringify(m.sources)} />
                    </div>
                  ))}
                </>
              )}
            </DiagCard>

            {/* SP Stream Resolve */}
            <DiagCard title="Layer 6: SP Stream Resolution (streamed.pk/api/stream)" icon={<Server className="h-5 w-5" />} ok={data.spStreamResolve?.ok}>
              {data.spStreamResolve && (
                <>
                  <DetailRow label="Source Type" value={data.spStreamResolve.source} />
                  <DetailRow label="Source ID" value={data.spStreamResolve.id} />
                  <DetailRow label="HTTP Status" value={data.spStreamResolve.status} bad={data.spStreamResolve.status >= 400} />
                  <DetailRow label="Streams Resolved" value={data.spStreamResolve.streamCount} />
                  {data.spStreamResolve.sampleStreams.map((s: any, i: number) => (
                    <div key={i} className="mt-2 rounded-lg border border-white/5 bg-black/20 p-3">
                      <DetailRow label="Embed URL" value={s.embedUrl} />
                      <DetailRow label="HD" value={s.hd} />
                      <DetailRow label="Language" value={s.language} />
                      <DetailRow label="Viewers" value={s.viewers} />
                    </div>
                  ))}
                </>
              )}
            </DiagCard>

            {/* embed.st direct */}
            <DiagCard title="Layer 7: embed.st Direct Fetch" icon={<Server className="h-5 w-5" />} ok={data.embedStDirect?.hasContent}>
              {data.embedStDirect && (
                <>
                  <DetailRow label="URL" value={(data.embedStDirect.url || '').slice(0, 100)} />
                  <DetailRow label="HTTP Status" value={data.embedStDirect.status} bad={data.embedStDirect.status >= 400} />
                  <DetailRow label="Body Size" value={`${data.embedStDirect.size} bytes`} />
                  <DetailRow label="Has Content (>500B)" value={data.embedStDirect.hasContent} />
                  <DetailRow label="X-Frame-Options" value={data.embedStDirect.frameBlockingHeaders.length > 0 ? data.embedStDirect.frameBlockingHeaders.join(', ') : 'NONE \u2705'} />
                  <DetailRow label="Popup Scripts" value={data.embedStDirect.hasPopupScripts} bad={data.embedStDirect.hasPopupScripts} />
                  <DetailRow label="Video Player" value={data.embedStDirect.hasVideoPlayer} />
                </>
              )}
            </DiagCard>
          </>
        )}
      </div>
    </div>
  );
}

function DiagCard({ title, icon, ok, error, children }: {
  title: string; icon: React.ReactNode; ok?: boolean; error?: string; children: React.ReactNode;
}) {
  return (
    <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3 }}
      className={`rounded-2xl border p-5 ${
        error ? 'border-amber-500/20 bg-amber-500/5' :
        ok === false ? 'border-red-500/20 bg-red-500/5' :
        ok ? 'border-emerald-500/20 bg-emerald-500/5' :
        'border-white/10 bg-slate-900/60'
      }`}>
      <div className="mb-4 flex items-center gap-3">
        <div className={`rounded-lg p-2 ${
          error ? 'bg-amber-500/20 text-amber-400' :
          ok === false ? 'bg-red-500/20 text-red-400' :
          ok ? 'bg-emerald-500/20 text-emerald-400' :
          'bg-white/10 text-slate-400'
        }`}>{icon}</div>
        <h3 className="text-sm font-bold text-white">{title}</h3>
        {ok !== undefined && !error && <StatusIcon status={ok ? 'ok' : 'fail'} />}
        {error && <AlertTriangle className="h-5 w-5 shrink-0 text-amber-400" />}
      </div>
      {error && <p className="mb-3 text-xs text-amber-300">{error}</p>}
      <div className="space-y-0.5">{children}</div>
    </motion.div>
  );
}
